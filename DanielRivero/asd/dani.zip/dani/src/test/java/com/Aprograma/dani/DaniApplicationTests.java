package com.Aprograma.dani;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaniApplicationTests {

	@Test
	void contextLoads() {
	}

}
