package com.Aprograma.dani;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaniApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaniApplication.class, args);
	}

}
